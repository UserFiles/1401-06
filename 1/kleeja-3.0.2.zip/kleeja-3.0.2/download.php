<?php
/**
*
* @package Kleeja
* @copyright (c) 2007 Kleeja.com
* @license ./docs/license.txt
*
*/

//
// we deprecated download.php , so we have to put it for those who upgraded
// to this version
//
require 'do.php';