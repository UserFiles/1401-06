<?php
/**
*
* @package Kleeja
* @copyright (c) 2007 Kleeja.com
* @license ./docs/license.txt
*
*/


//no for directly open
if (!defined('IN_COMMON'))
{
	exit();
}



define('KLEEJA_VERSION', '3.0.2');

define('KLEEJA_DB_VERSION', '9');



